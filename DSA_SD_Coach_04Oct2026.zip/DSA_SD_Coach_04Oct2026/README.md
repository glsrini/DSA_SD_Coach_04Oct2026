# DSA_SD_Coach_04Oct2026

A LangGraph coaching agent for DSA and system design interview prep (Aaroh rules enforced in code).
Design: see the "DSA_SD_COACH_4Oct2026 — Agent Design" doc.

## Status
Build phase 0: scaffolding only. `app/cli.py` (phase 1) does not exist yet, so the desktop shortcut will not start the coach until it does.

## Contents
| Path | What |
| --- | --- |
| `app/state.py` | Typed session state checked by the rule guards |
| `sql/schema.sql` | Learner, session and card tables plus the progress-log view, seeded with the first session |
| `launch_coach.bat` | Starts the coach (creates `.venv` on first run) |
| `create_shortcut.ps1` | Run once to put a desktop icon on Windows |
| `requirements.txt` | LangGraph, LangChain, Langfuse |

## Desktop shortcut
```powershell
powershell -ExecutionPolicy Bypass -File create_shortcut.ps1
```
